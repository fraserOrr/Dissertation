public class Subcriber{
	public String[] Subscriptions; 
}